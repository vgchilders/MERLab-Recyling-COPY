// Auto-generated. Do not edit!

// (in-package end_effector.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GripperState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.left_encoder = null;
      this.right_encoder = null;
      this.open = null;
      this.hasObject = null;
    }
    else {
      if (initObj.hasOwnProperty('left_encoder')) {
        this.left_encoder = initObj.left_encoder
      }
      else {
        this.left_encoder = 0.0;
      }
      if (initObj.hasOwnProperty('right_encoder')) {
        this.right_encoder = initObj.right_encoder
      }
      else {
        this.right_encoder = 0.0;
      }
      if (initObj.hasOwnProperty('open')) {
        this.open = initObj.open
      }
      else {
        this.open = false;
      }
      if (initObj.hasOwnProperty('hasObject')) {
        this.hasObject = initObj.hasObject
      }
      else {
        this.hasObject = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GripperState
    // Serialize message field [left_encoder]
    bufferOffset = _serializer.float64(obj.left_encoder, buffer, bufferOffset);
    // Serialize message field [right_encoder]
    bufferOffset = _serializer.float64(obj.right_encoder, buffer, bufferOffset);
    // Serialize message field [open]
    bufferOffset = _serializer.bool(obj.open, buffer, bufferOffset);
    // Serialize message field [hasObject]
    bufferOffset = _serializer.bool(obj.hasObject, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GripperState
    let len;
    let data = new GripperState(null);
    // Deserialize message field [left_encoder]
    data.left_encoder = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_encoder]
    data.right_encoder = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [open]
    data.open = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hasObject]
    data.hasObject = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'end_effector/GripperState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '03d6dbdf669cbb7a48c914755683f358';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 left_encoder
    float64 right_encoder
    bool open
    bool hasObject
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GripperState(null);
    if (msg.left_encoder !== undefined) {
      resolved.left_encoder = msg.left_encoder;
    }
    else {
      resolved.left_encoder = 0.0
    }

    if (msg.right_encoder !== undefined) {
      resolved.right_encoder = msg.right_encoder;
    }
    else {
      resolved.right_encoder = 0.0
    }

    if (msg.open !== undefined) {
      resolved.open = msg.open;
    }
    else {
      resolved.open = false
    }

    if (msg.hasObject !== undefined) {
      resolved.hasObject = msg.hasObject;
    }
    else {
      resolved.hasObject = false
    }

    return resolved;
    }
};

module.exports = GripperState;
