NOTE
-----For Conveyor------
The orientation of the conveyor means that reverse is true forward and forward is true reverse
the way the conveyor is coded it takes a 16bit signed int from -255 to 255 cooresponding to -30hz and 30hz respectively. Due to this the UI will intake the speed value and direction as a flat positive number and multiply it by the last direction dictated(initially set to forward) compensating for the directional difference between the true value and the indicated value.