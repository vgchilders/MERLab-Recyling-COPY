#!/usr/bin/env python3


import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from GUI_Template import Ui_Form
import cv2

import rospy
import numpy as np
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import String, Int16, Float32, Bool, Int32
from cv_bridge import CvBridge
from geometry_msgs.msg import Point
from time import sleep
#from arm_controller import Dynamixel, Teensy

#Estimated min and max discus further
speed_min = 0
speed_max = 30
speed_constant = 8.5
x_axis_min = 0
x_axis_max = 50
z_axis_min = 0
z_axis_max = 12
CONVEYOR_OFFSET_IN = 16
small_pickup_distance = 7 #constant z values for picking up items (-direction)
large_pickup_distance = 5

class GUI(Ui_Form):
    def __init__(self, Form):
        self.setupUi(Form)
        #variables representing state of robot -> data to be passed
        self.detectX = 0
        self.detectY = 0
        self.detectArea = 0
        self.manualX = 0
        self.manualZ = 0
        self.convSpeed = 0
        self.convDirection = 1 #1 means forward -1 means reverse
        self.gripState = True #True means open False means closed

        self.Img_Frame.mousePressEvent = self.pubMousePos
        Form.setWindowTitle("Conveyor Belt GUI")
        self.setup_SpinBox_Limits()
        self.setup_subscribers()
        self.setup_publishers()
        self.setup_signals()
        self.br = CvBridge()
        #self.Home_Button_Clicked() #Home system on start

    #Setting up GUI buttons
    def setup_signals(self):
        #GUI buttons associated w/ object detection window
        self.Start_Button.clicked.connect(self.Start_Button_Clicked)
        self.Kill_Button.clicked.connect(self.Kill_Button_Clicked)
        self.Img_RGB_Button.clicked.connect(self.RGB_Button_clicked)
        self.Img_Depth_Button.clicked.connect(self.Depth_Button_clicked)

        #GUI buttons for X-Axis controls
        self.X_Button.clicked.connect(self.X_Button_Clicked)
        self.Home_Button.clicked.connect(self.Home_Button_Clicked)
        self.Stop_Button.clicked.connect(self.Stop_Button_Clicked)

        #GUI buttons for Z-Axis/Gripper controls
        self.Z_Button.clicked.connect(self.Z_Button_Clicked)
        self.Grip_Open.clicked.connect(self.Grip_Open_Clicked) 
        self.Grip_Close.clicked.connect(self.Grip_Closed_Clicked)
        
        #GUI buttons for conveyor controls
        self.Speed_Button.clicked.connect(self.Speed_Button_Clicked)
        self.Conveyor_Forward.clicked.connect(self.Conveyor_Forward_Clicked)
        self.Conveyor_Reverse.clicked.connect(self.Conveyor_Reverse_Clicked)
        self.Conveyor_Stop.clicked.connect(self.Conveyor_Stop_Clicked)
        

    #Sets limits for camera display
    def setup_SpinBox_Limits(self):
        #Min and Max values for X Axis -NEEDS CHECK
        self.X_SpinBox.setMinimum(x_axis_min)
        self.X_SpinBox.setMaximum(x_axis_max)

        #Min and Max values for conveyor speed -NEEDS CHECK
        self.Speed_SpinBox.setMinimum(speed_min)
        self.Speed_SpinBox.setMaximum(speed_max)

        #Min and Max values for Z-Axis -NEEDS CHECK
        self.Z_SpinBox.setMinimum(z_axis_min)
        self.Z_SpinBox.setMaximum(z_axis_max)
        
    #Sets the fields and associates their values to callback for updating
    def setup_subscribers(self):
        self.subDetectX = rospy.Subscriber("object_detection/Xcoord", Float32, self.callback_detectX, queue_size=1)
        self.subDetectY = rospy.Subscriber("object_detection/Ycoord", Float32, self.callback_detectY, queue_size=1)
        self.subDetectArea = rospy.Subscriber("object_detection/Area", Float32, self.callback_detectArea, queue_size=1)
        self.sub_rgb = rospy.Subscriber("/camera/color/image_raw", Image, self.callback_rgb_image, queue_size=10)
        self.sub_depth = rospy.Subscriber("/camera/depth/image_rect_raw", Image, self.callback_depth_image)

    #Disconnects fields
    def disconnect_subscribers(self):
        self.sub_rgb.unregister()
        self.sub_depth.unregister()

    #setting up outputs
    def setup_publishers(self):
        self.pub_pixel_loc = rospy.Publisher("/gui_pixel_pos", Point, queue_size=1) #publishing mouse pos
        self.pubManualX = rospy.Publisher('controllers/manualX',Float32, queue_size=1)
        self.pubManualZ = rospy.Publisher('controllers/manualZ',Float32, queue_size=1)
        self.pubManualStop = rospy.Publisher('controllers/manualStop', Int16, queue_size=1)
        self.pubHome = rospy.Publisher('controllers/Home', Bool, queue_size=1)
        self.pubGripState = rospy.Publisher('controllers/gripState',Bool, queue_size=1)
        self.pubConveySpeed = rospy.Publisher('controllers/speed',Int16, queue_size=1) #indicates speed and direction
        self.pubKill = rospy.Publisher('controllers/kill', Int16, queue_size = 1)
    
        
    #updates images from camera
    def callback_rgb_image(self,data):
        if self.Img_RGB_Button.isChecked():
            frame = self.br.imgmsg_to_cv2(data,"bgr8")
            frame = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame,(640,480))
            self.Img_Frame.setPixmap(QtGui.QPixmap(QtGui.QImage(frame,frame.shape[1],frame.shape[0],frame.strides[0],QtGui.QImage.Format_RGB888)))

    def callback_depth_image(self,data):
        if self.Img_Depth_Button.isChecked():
            frame = self.br.imgmsg_to_cv2(data,"passthrough")
            frame = cv2.convertScaleAbs(frame,alpha=0.05)
            frame = cv2.cvtColor(frame,cv2.COLOR_GRAY2RGB)
            frame = cv2.resize(frame,(640,480))
            print(frame[0])
            self.Img_Frame.setPixmap(QtGui.QPixmap(QtGui.QImage(frame,frame.shape[1],frame.shape[0],frame.strides[0],QtGui.QImage.Format_RGB888)))
    
    #updates detected coordinates
    def callback_detectX(self, msg):
        self.detectX = float(msg.data)
        #print("Recieved detected X", msg.data)

    def callback_detectY(self, msg):
        self.detectY = float(msg.data)
    
    def callback_detectArea(self, msg):
        self.detectArea = float(msg.data)
        #print(self.detectArea)

    #sending values an input
    def pubMousePos(self, event):
        x = event.pos().x()
        y = event.pos().y()

        print("GUI:x: {0}, y: {1}, event: {2}".format(x, y, event))
        
        point = Point(x, y, 0)
        self.pub_pixel_loc.publish(point)

    #Functions for object detection window
    def RGB_Button_clicked(self):
        print("GUI:RGB Video Stream selected.")
    
    def Depth_Button_clicked(self):
        print("GUI:Depth Video Stream selected.")

    def Start_Button_Clicked(self):
        print("GUI:Starting robot based on detection coordinates.")
        #Pass detected coords
        self.pubManualX.publish(self.detectX + CONVEYOR_OFFSET_IN)
        if(self.detectArea < 75): #check if object is small or large
            self.pubManualZ.publish(small_pickup_distance)
        else:
            self.pubManualZ.publish(large_pickup_distance)

        #If conveyor speed is stopped default set to 15
        if(self.convSpeed <= 0):
            self.pubConveySpeed.publish(int(15 * speed_constant))
            self.convSpeed = 15
        #Calculate amount of time to get to position based on conveyor speed
        time = (((34 - self.detectY) + 38.25) / 
                ((2.86*self.convSpeed)/15)) #2.86 was the calculated velocity for conveyor speed 15
        sleep(time + 0.75) #additional time is only needed if conveyor stops if continues stream not needed
        self.pubConveySpeed.publish(0)
        self.convSpeed = 0
        #grab object and take it to drop zone
        self.pubGripState.publish(False)
        self.pubManualZ.publish(2)
        sleep(3)
        self.pubManualX.publish(5)
        sleep(3)
        #drop object and rehome
        self.gripState = True
        self.pubGripState.publish(True)
        self.manualX = 0
        self.manualZ = 0
        self.pubHome.publish(True)

    

    def Kill_Button_Clicked(self):
        print("GUI:Killing all processes")
        self.pubKill.publish(1)

    #Functions for gantry manual input
    def X_Button_Clicked(self):
        print("GUI:Moving X-Axis to ",self.X_SpinBox.value())
        self.manualX = self.X_SpinBox.value()
        self.pubManualX.publish(self.manualX)

    def Home_Button_Clicked(self):
        print("GUI:Homing gantry system")
        self.manualX = 0
        self.manualZ = 0
        self.pubHome.publish(True)

    def Stop_Button_Clicked(self):
        print("GUI:Stopping gantry system")
        self.pubManualStop.publish(1)
        

    #Functions for Z-Axis manual input
    def Z_Button_Clicked(self):
        print("GUI:Moving Z-Axis to ",self.Z_SpinBox.value())
        self.manualZ = self.Z_SpinBox.value()
        self.pubManualZ.publish(self.manualZ)
    
    def Grip_Open_Clicked(self):
        print("GUI:Opening Gripper")
        self.gripState = True
        self.pubGripState.publish(self.gripState)

    def Grip_Closed_Clicked(self):
        print("GUI:Closing Gripper")
        self.gripState = False
        self.pubGripState.publish(self.gripState)
        
    #Functions for conveyor manual input
    def Speed_Button_Clicked(self):
        print("GUI:Setting conveyor speed to ", self.Speed_SpinBox.value())
        self.convSpeed = int(self.Speed_SpinBox.value() * speed_constant)
        self.pubConveySpeed.publish(self.convSpeed * self.convDirection)
    
    def Conveyor_Forward_Clicked(self):
        #1 means forward
        print("GUI:Setting conveyor to move forward")
        self.convDirection = 1
        self.pubConveySpeed.publish(self.convSpeed * self.convDirection)

    def Conveyor_Reverse_Clicked(self):
        #-1 means reverse
        print("GUI:Setting conveyor to move reverse")
        self.convDirection = -1
        self.pubConveySpeed.publish(self.convSpeed * self.convDirection)

    def Conveyor_Stop_Clicked(self):
        print("GUI:Stopping conveyor")
        self.convSpeed = 0
        self.pubConveySpeed.publish(self.convSpeed)

    def exit(self):
        print("GUI:Exiting")
        self.disconnect_subscribers()

#Gui "main"
if __name__ == "__main__":
    rospy.init_node('gui', anonymous=True)
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = GUI(Form)  
    Form.show()
    app.exec_()
    ui.exit()
