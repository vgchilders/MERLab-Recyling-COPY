#!/usr/bin/env python3

# To run: 

# Terminal 1: roscore
# Terminal 2: run this file in vscode, make sure to cd to catkin workspace and run source devel/setup.bash
# Terminal 3: Use rostopic pub -1 /gripper_toggle end_effector/GripperToggle "{open: False/True}"

import os
import rospy
import serial
import time
from dynamixel_sdk import *
from dynamixel_sdk_examples.srv import *
from dynamixel_sdk_examples.msg import *
from tool_dynamixel import DynamixelMotor
from std_msgs.msg import Float64, String, Int32, Bool
from end_effector.msg import GripperToggle, GripperState

if os.name == 'nt':
    import msvcrt
    def getch():
        return msvcrt.getch().decode()
else:
    import sys, tty, termios
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    def getch():
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

# Dynamixel parameters

# Protocol version
PROTOCOL_VERSION    = 2.0               # See which protocol version is used in the Dynamixel

# Left finger encoder values
DXL1_OPEN_POS = 1300 #2011
DXL1_CLOSED_POS = 200 #1210, 300vert
# Right finger encoder values
DXL2_OPEN_POS = 1200 #2200
DXL2_CLOSED_POS = 300 #1200, 400vert

# Max load to trigger that an object has been grabbed
MAX_LOAD = 650

dxl_goal_left = [DXL1_OPEN_POS, DXL1_CLOSED_POS]         # Goal position
dxl_goal_right = [DXL2_OPEN_POS, DXL2_CLOSED_POS]         # Goal position

index = 0

# Default setting
DynamixelBAUDRATE   = 57600           # Dynamixel default baudrate : 57600
DynamixelDEVICENAME = '/dev/ttyUSB1'    # Check which port is being used on your controller

dynamixelPortHandler = PortHandler(DynamixelDEVICENAME)
dynamixelPacketHandler = PacketHandler(PROTOCOL_VERSION)

class GripperController:
    def __init__(self,DXL1_ID,DXL2_ID):
        self.left_finger = DynamixelMotor(DXL1_ID, dynamixelPortHandler, dynamixelPacketHandler)
        self.right_finger = DynamixelMotor(DXL2_ID, dynamixelPortHandler, dynamixelPacketHandler)

        # Enable torque
        self.left_finger.enable_torque()  
        self.right_finger.enable_torque()
        
        rospy.Subscriber('gripper_toggle', Bool, callback=self.toggleGripper, queue_size=1)
        
        self.pub_gripper = rospy.Publisher('gripper_state', GripperState, queue_size=1)

        print("gripper_controller: Dynamixel ready to control")
        
    # Opens the gripper
    def open_gripper(self):
        gripper = GripperState()
        index = 0
        while not self.left_finger.set_goal_position(dxl_goal_left[index]): pass
        while not self.right_finger.set_goal_position(dxl_goal_right[index]): pass
        
        #publish to gripper state message
        gripper.left_encoder = self.left_finger.get_position()
        gripper.right_encoder = self.right_finger.get_position()
        gripper.open = True
        gripper.hasObject = False
        
        self.pub_gripper.publish(gripper)
    
    # Closes the gripper either to max encoder value or until the max load is hit
    def close_gripper(self):
        gripper = GripperState()
        index = 1
        hasObject = False
        left_pos = 0
        right_pos = 0
        while not self.left_finger.set_goal_position(dxl_goal_left[index]):
            print("closing")
            if self.left_finger.get_load() <= MAX_LOAD and self.right_finger.get_load() <= MAX_LOAD:
                hasObject = True
                left_pos = self.left_finger.get_position()
                right_pos = self.right_finger.get_position()
                break
            rospy.sleep(0.01)
        while not self.right_finger.set_goal_position(dxl_goal_right[index]):
            print("closing")
            if self.left_finger.get_load() <= MAX_LOAD and self.right_finger.get_load() <= MAX_LOAD:
                hasObject = True
                left_pos = self.left_finger.get_position()
                right_pos = self.right_finger.get_position()
                break
            rospy.sleep(0.01)
        
        
        #publish to gripper message
        gripper.left_encoder = self.left_finger.get_position()
        gripper.right_encoder = self.right_finger.get_position()
        gripper.open = False
        gripper.hasObject = hasObject
        
        self.pub_gripper.publish(gripper)
        
        # If the gripper detects it has an object, then it will hold its current position rather than keep closing
        if hasObject:
            print("Grabbed object!")
            while 1:
                self.left_finger.set_goal_position(left_pos)
                self.right_finger.set_goal_position(right_pos)
        
        
    def toggleGripper(self, msg):
        if msg.data:
            self.open_gripper()
        else:
            self.close_gripper()
        
    
def controller_node():
    rospy.init_node('end_effector')
    GripperController(1,2)
    print("gripper_controller:Setup Finished")
    rospy.spin()
    
def main():
    # Open port
    try:
       dynamixelPortHandler.openPort()
       print("arm_controller:Succeeded to open the port for dynamixel")
    except:
        print("arm_controller:Failed to open the port for dynamixel")
        print("arm_controller:Press any key to terminate...")
        getch()
        quit()

    # Set port baudrate
    try:
        dynamixelPortHandler.setBaudRate(DynamixelBAUDRATE)
        print("arm_controller:Succeeded to change the baudrate for dynamixel")
    except:
        print("arm_controller:Failed to change the baudrate for dynamixel")
        print("arm_controller:Press any key to terminate...")
        getch()
        quit()

    controller_node()

if __name__ == '__main__':
    main()
        