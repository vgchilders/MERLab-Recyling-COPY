How to run:

	Terminal #1: roscore
	Terminal #2: rosrun end_effector gripper_controller.py 
 (Make sure to cd to the active catkin workspace, in this case the "recycling" folder. If this doesn't work, try sourcing devel/setup.bash in vscode terminal and run there)

To toggle the gripper open/close:

	Terminal #3: rostopic pub -1 gripper_toggle std_msgs/Bool True

ROS Topics>======================================================================

Subscriber:

	GripperToggle -> toggles the gripper position
	open: boolean
	
Publisher:

	GripperState -> contians information on what state the gripper is in
	left_encoder: float64
	right_encoder: float64
	open: boolean
	hasObject: boolean

Note: the dynamixels communicate through dev/ttyUSB1
