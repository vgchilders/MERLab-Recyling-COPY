#!/usr/bin/env python3
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import cv2

import rospy
import numpy as np
import subprocess
from sensor_msgs.msg import Image, PointCloud2
from cv_bridge import CvBridge
from std_msgs.msg import Bool, Int16, Float32
from geometry_msgs.msg import Point
from time import sleep


class masterController():

    def __init__(self):
        self.setup_subscribers()
        self.setup_publishers()
        self.manualX = 0
        self.manualZ = 0
        self.detectedX = 0
        self.detectedY = 0
        self.convSpeed = 0
        self.gripState = True
    
    #callback can reference functions in arms
    #provided the master contains instances of the other classes
    #   this could be used to allow the master to alter the values and command movement more directly
    def setup_subscribers(self):
        #GUI Subscribers
        self.subManualX = rospy.Subscriber("controllers/manualX", Float32, callback=self.callbackManX, queue_size=1)
        self.subManualZ = rospy.Subscriber("controllers/manualZ", Float32, callback=self.callbackManZ, queue_size=1)
        self.subManualStop = rospy.Subscriber("controllers/manualStop", Int16, callback=self.callbackManualStop, queue_size=1)
        self.subGripState = rospy.Subscriber("controllers/gripState", Bool, callback=self.callbackGrip, queue_size=1)
        self.subConveySpeed = rospy.Subscriber("controllers/speed", Int16, callback=self.callbackSpeed, queue_size=1) #indicates speed and direction
        self.subKill = rospy.Subscriber("controllers/kill", Int16, callback=self.callbackKill, queue_size=1)
        self.subHome = rospy.Subscriber("controllers/Home", Bool, callback=self.callbackHome, queue_size=1)

    def setup_publishers(self):
        #Conveyor publisher
        self.pubSetConveyor = rospy.Publisher('/beltSpeed2', Int16, queue_size=1)
        #Gantry publishers
        self.pubHome = rospy.Publisher("gantry/Home", Bool, queue_size=1)
        self.pubX = rospy.Publisher("gantry/X", Float32, queue_size=1)
        self.pubZ = rospy.Publisher("gantry/Z", Float32, queue_size=1)
        #End Effector publisher
        self.pubGrip = rospy.Publisher("gripper_toggle", Bool, queue_size=1)


    def callbackManualStop(self, msg):
        if msg.data == 1:
            subprocess.run(['rosnode', 'kill', 'gantry'])

    def callbackKill(self, msg):
        if msg.data == 1:
            subprocess.run(['rosnode', 'kill', '-a'])
    
    #Stores the message values before calling the coorelating functionality from the system
    def callbackManX(self, msg):
        self.manualX = msg.data
        self.pubX.publish(self.manualX)
    
    def callbackManZ(self, msg):
        self.manualZ = msg.data
        self.pubZ.publish(self.manualZ)

    def callbackHome(self, msg):
        self.manualX = 0
        self.manualZ = 0
        self.pubHome.publish(msg.data)
    
    def callbackDetectY(self, msg):
        self.detectedY = msg.data
        return msg.data #change to reference conveyor if applicable
    
    def callbackSpeed(self, msg):
        self.convSpeed = msg.data
        self.pubSetConveyor.publish(self.convSpeed)
    
    def callbackGrip(self,msg):
        self.gripState = msg.data
        self.pubGrip.publish(self.gripState)





if __name__ == '__main__':
    rospy.init_node('controllers', anonymous=True)
    m = masterController()
    # sleep(2)
    # m.home_robot()
    # while(True):
    # 	m.move_arm(1,1)
    # 	m.move_arm(43,79)
    rospy.spin()