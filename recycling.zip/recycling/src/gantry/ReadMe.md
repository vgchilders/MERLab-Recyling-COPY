build for arduino uno R3

requires FastAccelStepper library (uses hardware timers)

requires rosserial serial.py node to be running on
host computer 

does not currently handle what to do when given a out of bounds position or hits a end stop.

Pinout>===========================================================================

GantryX
	Step: 6
	Direction: 5
	enable: 4
	lower limit switch: 23
	upper limit switch: 25 (currently does nothing)

GantryZ
	Step: 7
	Direction: 12
	enable: 11
	lower limit switch: 27
	upper limit switch: 29 (currently does nothing)
	
ROS Topics>======================================================================

subscribers
	SetGantryXPos
	type: Float 32
	sets the gantry x position in inches from zero
	
	
	SetGantryZPos
	type: Float 32
	(needs fix to reflect geometry of actual system)
	sets gantry Z position in inches from zero 
	
	
	homeGantryX
	type: empty
	tells system to home gantry X axis. system also stops outputting position
	
	homeGantryZ
	type: empty
	tells system to home gantry Z axis. system also stops outputting position
	

Publishers
	gantryPosX
	type: int16
	outputs current x position in motor ticks
	
	gantryPosZ
	type: int16
	outputs current z postition in motor ticks
	
	homingXComplete
	type: bool
	outputs true when system is ready to take inputs on the X axis
	
	homingZComplete
	type: bool
	outputs true when system is ready to take inputs on the Z axis
	
	

Homing system>===================================================================

before the system can (and should) operate the ready flag needs to be set to true
to do this send a empty message on the homeGantryX and HomeGantryZ topics.

this works by slowly bumping the gantry into the limit switch then backing off
the limit switch until the input is not detected. this is where zero is set.

X axis Out of bounds Handling>===================================================

If a message is sent to /SetGantryXPos that is greater than the upper limit or
lower than the lower limit the input is set to that respective limit and no
feedback is given to the system


X axis Crash Detection>==========================================================

If on the Xaxis collides with the lower or upper limit switches the system
the Xaxis will coast to as stop in 5ms if not trying to home itself.

The Z axis will continue to move.

when the colision happens /homingXComplete will publish False

The gantry needs to be homed again to continue opperation

If the Xaxis is crashing frequently consider changing the Xaxis aceleration or speed.


E-stop>==========================================================================
NOT YET implemented

though the system will coast to a stop once the stepper drivers die due to lack
of 24 volts.

dev env>=========================================================================

To Compile this code you will need the following Arduino libraries
	Rosserial Arduino libraries v0.7.9 (0.9.1 seems to be missing files)
	FastAccelStepper v0.30.0

I would recommend working with the Arduino IDE 1.8.9 or 2.2 on windows since
IDE does not seem to be stable on ubuntu 20.04.

In the future i may move to platformio if the scope of the code that runs on
the Arduinos increase and it may be more stable on arduinos



ros env setup>===================================================================

To get the ardunio to talk to "ROS land" the following packages are needed:
	rosserial_python
	
to turn on the node to talk to ros core the following must be run:
	rosrun rosserial_python serial_node.py /dev/ttyAMC0
	
the last argument may have to be changed depending
on where the ardunio device is mounted

use ros noetic


control demos>====================================================================
build for arduino uno

requires FastAccelStepper library

these series of codes were to test various functionalitys of the library
	control demo 1: show that the stepper library will work with the thing
	control demo 2: add another stepper
	control demo 3: add ros messages
