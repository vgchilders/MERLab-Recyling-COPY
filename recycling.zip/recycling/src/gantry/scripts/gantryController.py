#!/usr/bin/env python3
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import cv2

import rospy
import numpy as np
import subprocess
from sensor_msgs.msg import Image, PointCloud2
from cv_bridge import CvBridge
from std_msgs.msg import Int16, Float32, Empty, Bool
from geometry_msgs.msg import Point
from time import sleep

class gantryController():
    def __init__(self):
        self.setup_subscribers()
        self.setup_publishers()
        self.X = 0
        self.Z = 0
        self.timer = 0
        self.homeCount = 0
        self.homeX = False
        self.homeZ = False

    def setup_subscribers(self):
        #subscribers for master
        self.subX = rospy.Subscriber("gantry/X", Float32, callback=self.callbackX, queue_size=1)
        self.subZ = rospy.Subscriber("gantry/Z", Float32, callback=self.callbackZ, queue_size=1)
        self.subHome = rospy.Subscriber("gantry/Home", Bool, callback=self.callbackHome, queue_size=1)
        #subscribers for stepper
        self.subCurrX = rospy.Subscriber('gantryPosX',Int16, callback=self.logXPos, queue_size=1)
        self.subCurrZ = rospy.Subscriber('gantryPosZ',Int16, callback=self.logZPos, queue_size=1)
        self.subHomeStatusX = rospy.Subscriber('homingXComplete',Bool,callback=self.setHomeX, queue_size=1)
        self.subHomeStatusZ = rospy.Subscriber('homingZComplete',Bool,callback=self.setHomeZ, queue_size=1)
    
    def setup_publishers(self):
        #publishers for master
        self.pubCurrX = rospy.Publisher('master/currX',Int16, queue_size=1)
        self.pubCurrZ = rospy.Publisher('master/currZ',Int16, queue_size=1)
        self.pubHomeStatus = rospy.Publisher('master/homeStatus',Int16, queue_size=1)
        #publishers for stepper
        self.pubX = rospy.Publisher('SetGantryXPos',Float32, queue_size=1)
        self.pubZ = rospy.Publisher('SetGantryZPos',Float32, queue_size=1)
        self.pubHomeX = rospy.Publisher('homeGantryX',Empty, queue_size=1)
        self.pubHomeZ = rospy.Publisher('homeGantryZ',Empty, queue_size=1)

    #Callbacks for sending info to the steppers
    def callbackX(self, msg):
        self.X = msg.data
        self.pubX.publish(self.X)

    def callbackZ(self, msg):
        self.Z = msg.data * -1
        self.pubZ.publish(self.Z)

    def callbackHome(self, msg):
        self.X = 0
        self.Z = 0
        self.homeCount = 0
        self.pubHomeZ.publish()
        

    #Callbacks for debugging feedback from steppers
    def logXPos(self, msg):
        if(msg.data != 0 and self.timer % 200 == 0):
            print("Current X Position: ", msg.data)
            self.timer += 1

    def logZPos(self, msg):
        if(msg.data != 0 and self.timer % 200 == 0):
            print("Current Z Position: ", msg.data)
            self.timer += 1

    def setHomeX(self, msg):
        self.homeX = msg.data
        print("Current X Status ", self.homeX, "Current Z Status ", self.homeZ)
        
    def setHomeZ(self, msg):
        self.homeZ = msg.data
        print("Current X Status ", self.homeX, "Current Z Status ", self.homeZ)
        if(self.homeZ and (self.homeCount == 0)):
            self.pubHomeX.publish()
            self.homeCount += 1



if __name__ == '__main__':
    rospy.init_node('gantry', anonymous=True)
    g = gantryController()
    rospy.spin()