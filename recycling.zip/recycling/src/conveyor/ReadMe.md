the belt uses the following pin mappings on an arduino uno R3

belt 1
	Frequency: 6 (PWM pin)
	Direction: 13
	motorStart: 12
	
belt 2
	Frequency: 5 (PWM pin)
	Direction: 3
	motorStart: 2

to my knowlege there is nothing that would prevent this from running on different
boards such as the MKR1010 or uno R4 as long as the hardware is configured
correctly

dev env>=========================================================================

To Compile this code you will need the following Arduino libraries
	Rosserial Arduino libraries v0.7.9 (0.9.1 seems to be missing files)

I would recommend working with the Arduino IDE 1.8.9 on windows since
IDE does not seem to be stable on ubuntu 20.04.

In the future i may move to platformio if the scope of the code that runs on
the Arduinos increase and it may be more stable on arduinos


ros env setup>===================================================================

To get the ardunio to talk to "ROS land" the following packages are needed:
	rosserial_python
	
to turn on the node to talk to ros core the following must be run:
	rosrun rosserial_python serial_node.py /dev/ttyACM0
	
the last argument may have to be changed depending
on where the ardunio device is mounted

though i have not tested this yet (12/11/23) in theory you could use the
"rosserial_server" package and its C++ PC side ros node that takes advangage of
C++ being signifantly faster that python in terms of performance.


ros subscribers>=====================================================================

the node subscribes to the following
	/beltSpeed1 (Feeder belt)
	/beltSpeed2 (Main belt)

both of these messages are of type Int16, 16 bit signed intergers
they are expecting a value between -255 and 255. 
this sets the direction Frequency, and motorStart.

the values are mapped as -255 to 255 -> -30hz to 30hz on the VFD linearly

when the frequency is set to 0 the motor direction is fowards and the
motor is stopped

when a value is sent that is outside -255 to 255 range the system sets the 
direction correctly, keeps the old frequency, and stops the motor.


ros publishers>==================================================================

the node published the following messages
	/beltDebug
	
this message is of type String.

this published as message that is of what motor values were just upated with
the inital number refering to the motor number.

this same message is also published to roslog but im incompetent which is why
i need a entire ros topic to do this.

- Nicholas, salochinYom, Moy

