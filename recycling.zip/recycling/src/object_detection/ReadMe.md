Working on untangling the past code 
So far it seems the past team used a custom trained YOLOv5 model and drew boxes after an image was run through the model
I want to see if I can replace the normal camera view in the GUI with the identified version and hopefully get rid of the second interface

Changed camera_gui_node to imageBuilder -> imageBuilder is a class that is mean to take the image from the camera draw the detected objects using an instance of object_detection_model
and send that to the GUI for display

TODO:
Find how the subscriber references that recieve the Raw Image are getting called?
This is in the GUI and camera_gui -> where is the image being published for them to recieve?

